-- test stratnum support func
SELECT gist_stratnum_btree(3::smallint);
SELECT gist_stratnum_btree(18::smallint);
